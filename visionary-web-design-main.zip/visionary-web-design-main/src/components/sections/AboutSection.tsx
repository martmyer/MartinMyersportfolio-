import { Code, Users, Heart, Briefcase, GraduationCap, Award } from "lucide-react";

const skills = [
  { name: "Customer Support", level: 95 },
  { name: "Technical Troubleshooting", level: 90 },
  { name: "Zendesk & Salesforce", level: 88 },
  { name: "Data Analysis", level: 85 },
  { name: "Figma & UI Design", level: 80 },
  { name: "Excel & Power BI", level: 85 },
];

const highlights = [
  {
    icon: GraduationCap,
    title: "B.S. Informatics",
    description: "Indiana University Bloomington, Human-Centered Computing",
  },
  {
    icon: Briefcase,
    title: "Group1001",
    description: "Customer Service Coordinator, Technical & Product Support",
  },
  {
    icon: Heart,
    title: "Community Focused",
    description: "Active volunteer with Keep Indianapolis Beautiful & Habitat for Humanity",
  },
  {
    icon: Award,
    title: "HR Experience",
    description: "End-to-end recruitment & compliance at Applied Behavior Center for Autism",
  },
];

const AboutSection = () => {
  return (
    <section id="about" className="py-24 lg:py-32 bg-card relative overflow-hidden">
      {/* Diagonal Background Element */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute -top-1/2 -right-1/4 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-1/2 -left-1/4 w-[600px] h-[600px] bg-secondary/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-widest mb-4 block">
            About Me
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
            Blending <span className="text-gradient">Technology</span> with Service
          </h2>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto leading-relaxed">
            Originally from Indianapolis, Indiana, I hold a Bachelor of Science in Informatics 
            with a concentration in Human-Centered Computing from Indiana University. My academic 
            background and professional experience have equipped me with a strong foundation in 
            technology, client support, and human resources.
          </p>
        </div>

        {/* Staggered Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {highlights.map((item, index) => (
            <div
              key={item.title}
              className={`glass-card p-6 rounded-2xl hover:border-primary/40 transition-all duration-500 hover:-translate-y-2 group ${
                index % 2 === 1 ? 'lg:translate-y-8' : ''
              }`}
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 group-hover:scale-110 transition-all duration-300">
                <item.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                {item.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        {/* Bio & Skills Split */}
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Bio */}
          <div className="glass-card p-8 rounded-2xl">
            <h3 className="font-display text-2xl font-semibold text-foreground mb-6 flex items-center gap-3">
              <Users className="w-6 h-6 text-primary" />
              My Journey
            </h3>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                I have contributed to diverse organizations, including providing technical and 
                product support at Group1001 and overseeing recruitment and HR operations at 
                the Applied Behavior Center for Autism. These roles have allowed me to blend 
                technical expertise with a commitment to exceptional service.
              </p>
              <p>
                Beyond my professional endeavors, I am deeply engaged in community service. 
                I actively participate in environmental cleanups and volunteer construction 
                projects, including initiatives through Keep Indianapolis Beautiful and other 
                workplace-sponsored programs.
              </p>
              <p className="text-primary font-medium">
                I am passionate about using my skills to make a positive impact—both in the 
                workplace and in the community.
              </p>
            </div>
          </div>

          {/* Skills */}
          <div className="glass-card p-8 rounded-2xl">
            <h3 className="font-display text-2xl font-semibold text-foreground mb-6 flex items-center gap-3">
              <Code className="w-6 h-6 text-primary" />
              Skills & Expertise
            </h3>
            <div className="space-y-5">
              {skills.map((skill, index) => (
                <div key={skill.name} className="group">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-foreground font-medium text-sm">{skill.name}</span>
                    <span className="text-primary text-sm font-semibold">{skill.level}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all duration-1000 ease-out"
                      style={{ 
                        width: `${skill.level}%`,
                        animation: `slideInWidth 1s ease-out ${index * 100}ms forwards`
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Diagonal Divider to next section */}
      <svg 
        className="absolute bottom-0 left-0 right-0 w-full h-16 text-background"
        viewBox="0 0 1440 48" 
        preserveAspectRatio="none"
      >
        <path 
          d="M0,48 L1440,48 L1440,0 L0,48 Z" 
          fill="currentColor"
        />
      </svg>
    </section>
  );
};

export default AboutSection;
