import { Briefcase, GraduationCap, Download, Calendar, Heart, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

const experience = [
  {
    title: "Customer Service Coordinator",
    company: "Group1001",
    period: "Feb 2025 - Present",
    description: "Respond to 25–45 client and agent inquiries daily using Zendesk, Salesforce, and Onyx, consistently delivering high-quality technical and product support.",
    achievements: [
      "Web portal troubleshooting",
      "Cross-functional collaboration",
      "Exceeds quality benchmarks"
    ],
  },
  {
    title: "One Portal Coordinator",
    company: "Group1001",
    period: "Feb 2024 – Feb 2025",
    description: "Primary point of contact for 25–45 daily client and agent login and portal inquiries, providing high-quality technical support.",
    achievements: [
      "Password resets & validation",
      "Case ownership until resolution",
      "Usability improvement reports"
    ],
  },
  {
    title: "HR Associate & Recruiter",
    company: "Applied Behavior Center for Autism",
    period: "Mar 2023 - Dec 2023",
    description: "Led end-to-end recruitment efforts for six ABA centers across Indiana, including candidate sourcing, screening, interviewing, and hiring.",
    achievements: [
      "I-9, E-Verify, FMLA compliance",
      "ADP Workforce administration",
      "Workplace investigations"
    ],
  },
  {
    title: "Lifeguard & Facility Operations",
    company: "Life Time Fitness",
    period: "Nov 2022 - Mar 2023",
    description: "Certified Red Cross Lifeguard for CPR, AED, First Aid. Monitored pool safety and maintained facility operations.",
    achievements: [
      "Safety protocol enforcement",
      "Chemical level tracking",
      "Emergency response"
    ],
  },
];

const education = {
  degree: "Bachelor of Science in Informatics",
  concentration: "Human-Centered Computing",
  school: "Indiana University Bloomington",
  period: "2018 - 2023",
};

const volunteering = [
  {
    org: "Keep Indianapolis Beautiful",
    role: "Community Cleanup Volunteer",
    period: "2024 - Present",
    description: "Led volunteer teams for plogging initiatives across Downtown Indianapolis."
  },
  {
    org: "Habitat for Humanity",
    role: "Company Volunteer (Group1001)",
    period: "2025",
    description: "Constructed and renovated affordable homes for low-income families."
  },
  {
    org: "IU Student Congress",
    role: "Representative for Apartment & Family Housing",
    period: "2019 - 2020",
    description: "Liaison between constituents and organizational leadership."
  },
];

const ResumeSection = () => {
  return (
    <section id="resume" className="py-24 lg:py-32 bg-card relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-primary/5 to-transparent pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-gradient-to-tr from-secondary/5 to-transparent pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-widest mb-4 block">
            Resume
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
            Professional <span className="text-gradient">Journey</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
            Making meaningful impact through technology, client support, and community engagement.
          </p>
          <a
            href="https://docs.google.com/document/d/1cUzNFnH5XQ8zkmqyjsLY6pGqSDZhLnUABdlB1MUfodk/edit?tab=t.0"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button variant="hero" size="lg">
              <Download size={18} />
              Download Full Resume
              <ExternalLink size={14} className="ml-1" />
            </Button>
          </a>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Experience Column - Takes 2 cols */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Briefcase className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-2xl font-semibold text-foreground">
                Work Experience
              </h3>
            </div>

            {/* Staggered Experience Cards */}
            <div className="grid md:grid-cols-2 gap-6">
              {experience.map((job, index) => (
                <div
                  key={`${job.title}-${job.company}`}
                  className={`glass-card p-6 rounded-xl hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 ${
                    index % 2 === 1 ? 'md:translate-y-6' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 text-primary text-sm font-medium mb-2">
                    <span className="px-2 py-0.5 bg-primary/10 rounded text-xs">
                      {job.company}
                    </span>
                  </div>
                  <h4 className="font-display text-lg font-semibold text-foreground mb-1">
                    {job.title}
                  </h4>
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-3">
                    <Calendar size={14} />
                    {job.period}
                  </div>
                  <p className="text-muted-foreground text-sm mb-4 leading-relaxed line-clamp-2">
                    {job.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {job.achievements.map((achievement) => (
                      <span
                        key={achievement}
                        className="px-2 py-1 text-xs bg-muted text-muted-foreground rounded"
                      >
                        ✓ {achievement}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education & Volunteering Column */}
          <div className="space-y-8">
            {/* Education */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-secondary/20 flex items-center justify-center">
                  <GraduationCap className="w-6 h-6 text-secondary" />
                </div>
                <h3 className="font-display text-2xl font-semibold text-foreground">
                  Education
                </h3>
              </div>

              <div className="glass-card p-6 rounded-xl hover:border-primary/30 transition-colors glow-effect">
                <h4 className="font-display text-lg font-semibold text-foreground mb-1">
                  {education.degree}
                </h4>
                <p className="text-primary text-sm font-medium mb-2">
                  {education.concentration}
                </p>
                <p className="text-foreground font-medium mb-1">
                  {education.school}
                </p>
                <div className="flex items-center gap-2 text-muted-foreground text-sm">
                  <Calendar size={14} />
                  {education.period}
                </div>
              </div>
            </div>

            {/* Volunteering */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Heart className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-display text-2xl font-semibold text-foreground">
                  Community
                </h3>
              </div>

              <div className="space-y-4">
                {volunteering.map((vol) => (
                  <div 
                    key={vol.org} 
                    className="glass-card p-4 rounded-xl hover:border-primary/30 transition-colors"
                  >
                    <h4 className="font-display text-base font-semibold text-foreground mb-1">
                      {vol.org}
                    </h4>
                    <p className="text-primary text-sm font-medium">{vol.role}</p>
                    <p className="text-muted-foreground text-xs mt-1">{vol.period}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Diagonal Divider */}
      <svg 
        className="absolute bottom-0 left-0 right-0 w-full h-16 text-background"
        viewBox="0 0 1440 48" 
        preserveAspectRatio="none"
      >
        <path 
          d="M0,48 L1440,48 L1440,0 C1080,48 720,24 360,48 C180,60 90,48 0,48 Z" 
          fill="currentColor"
        />
      </svg>
    </section>
  );
};

export default ResumeSection;
