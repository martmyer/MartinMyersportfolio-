import { ArrowDown, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import martinPhoto from "@/assets/martin-myers.jpg";
import iuLogo from "@/assets/iu-logo.png";

const HeroSection = () => {
  const scrollToAbout = () => {
    document.getElementById("about")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-card to-background" />
      
      {/* Floating Orbs */}
      <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-primary/20 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/15 rounded-full blur-3xl animate-float animation-delay-300" />
      <div className="absolute top-1/2 right-1/3 w-48 h-48 bg-accent/10 rounded-full blur-2xl animate-float animation-delay-500" />
      
      {/* Grid Pattern Overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(hsl(var(--primary)) 1px, transparent 1px),
                            linear-gradient(90deg, hsl(var(--primary)) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }}
      />

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Profile Photo */}
          <div className="mb-8 animate-fade-up">
            <div className="relative inline-block">
              <div className="w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-primary/20 shadow-xl">
                <img 
                  src={martinPhoto} 
                  alt="Martin Myers" 
                  className="w-full h-full object-cover"
                  style={{ imageRendering: 'auto', WebkitBackfaceVisibility: 'hidden' }}
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-9 h-9 bg-white rounded-full flex items-center justify-center border-2 border-background overflow-hidden p-0.5">
                <img src={iuLogo} alt="Indiana University" className="w-full h-full object-contain" />
              </div>
            </div>
          </div>

          {/* Status Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8 animate-fade-up animation-delay-100">
            <span className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
            <span className="text-sm font-medium text-primary">Open to New Opportunities</span>
          </div>

          {/* Main Heading */}
          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold text-foreground mb-6 animate-fade-up animation-delay-200">
            Hi, I'm{" "}
            <span className="text-gradient relative">
              Martin Myers
            </span>
          </h1>

          {/* Subtitle with Staggered Animation */}
          <div className="space-y-2 mb-8">
            <p className="text-xl md:text-2xl lg:text-3xl text-muted-foreground animate-fade-up animation-delay-300">
              Customer Service Coordinator at{" "}
              <span className="text-foreground font-medium">Group1001</span>
            </p>
            <p className="text-lg md:text-xl text-muted-foreground animate-fade-up animation-delay-400">
              Informatics Graduate • Tech & Client Support Specialist
            </p>
          </div>

          {/* Location */}
          <div className="flex items-center justify-center gap-2 text-muted-foreground mb-10 animate-fade-up animation-delay-500">
            <MapPin size={18} className="text-primary" />
            <span>Indianapolis, Indiana</span>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up animation-delay-500">
            <Button 
              variant="hero" 
              size="lg"
              onClick={() => document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })}
              className="group"
            >
              View My Work
              <ArrowDown size={18} className="ml-2 group-hover:translate-y-1 transition-transform" />
            </Button>
            <Button 
              variant="glass" 
              size="lg"
              onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            >
              Get In Touch
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button 
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground hover:text-primary transition-colors cursor-pointer animate-fade-up animation-delay-500"
      >
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <div className="w-6 h-10 rounded-full border-2 border-current flex items-start justify-center p-1">
          <div className="w-1.5 h-3 bg-current rounded-full animate-bounce" />
        </div>
      </button>

      {/* Diagonal Divider */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-b from-transparent to-card" />
      <svg 
        className="absolute bottom-0 left-0 right-0 w-full h-16 text-card"
        viewBox="0 0 1440 48" 
        preserveAspectRatio="none"
      >
        <path 
          d="M0,48 L1440,48 L1440,24 C1080,48 720,0 360,24 C180,36 90,48 0,48 Z" 
          fill="currentColor"
        />
      </svg>
    </section>
  );
};

export default HeroSection;
