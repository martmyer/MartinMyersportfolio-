import { ExternalLink, Figma, FileSpreadsheet, BarChart3, ArrowRight, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const projects = [
  {
    title: "Keep Indianapolis Beautiful App",
    type: "FIGMA",
    description:
      "Mobile application concept for the volunteer organization Keep Indianapolis Beautiful, Inc. Designed a mobile experience that stays true to the organization's branding while improving accessibility for on-the-go volunteers.",
    outcomes: [
      "Personal volunteer accounts",
      "Volunteer hour tracking",
      "Modernized user experience",
      "Enhanced community engagement"
    ],
    icon: Figma,
    liveUrl: "https://www.figma.com/proto/lY3ObiaP6vh6zIJ6AP2qay/KIB?node-id=7-941&p=f&t=Xjebm5pH2eEOteMJ-0&scaling=scale-down&content-scaling=fixed&page-id=0%3A1&starting-point-node-id=7%3A941&show-proto-sidebar=1",
    color: "from-purple-500 to-pink-500",
    featured: true,
  },
  {
    title: "NET 300 Gradebook",
    type: "EXCEL",
    description:
      "Created a comprehensive gradebook for theoretical Class NET 300 as part of a self-designed project. Applied formulas to calculate grades, convert to percentages, and used conditional formatting to identify students requiring support.",
    outcomes: [
      "Max, min, average calculations",
      "Conditional formatting",
      "Column chart visualizations",
      "Performance gap analysis"
    ],
    icon: FileSpreadsheet,
    liveUrl: "https://drive.google.com/file/d/1FwcsyW70IQxPw5fOu-fzVg5g7q6guOwm/view",
    color: "from-green-500 to-emerald-500",
    featured: true,
  },
  {
    title: "Chocolate Sales Report",
    type: "POWER BI",
    description:
      "Interactive business report exploring sales performance across products, salespersons, countries, and time periods. Incorporated line charts, bar charts, donut charts, KPI cards, and slicers for dynamic filtering.",
    outcomes: [
      "Multi-dimensional analysis",
      "Interactive date filtering",
      "Real-time refresh",
      "Collaborative sharing"
    ],
    icon: BarChart3,
    liveUrl: "https://app.powerbi.com/links/OIXhp4IsiL?ctid=0ea7bba9-6311-47d8-be00-91b71da2d6f7&pbi_source=linkShare",
    color: "from-amber-500 to-orange-500",
    featured: true,
  },
  {
    title: "Project 4",
    type: "COMING SOON",
    description:
      "New project currently in development. Stay tuned for updates on this exciting new addition to my portfolio.",
    outcomes: [],
    icon: Clock,
    liveUrl: "#",
    color: "from-blue-500 to-cyan-500",
    featured: false,
  },
];

const ProjectsSection = () => {
  return (
    <section id="projects" className="py-24 lg:py-32 bg-background relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] bg-primary/5 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-widest mb-4 block">
            Portfolio
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
            Featured <span className="text-gradient">Projects</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A selection of projects showcasing my skills in UI/UX design, data analysis, 
            and business intelligence.
          </p>
        </div>

        {/* Staggered Cards Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {projects.filter(p => p.featured).map((project, index) => (
            <article
              key={project.title}
              className={`group relative bg-card rounded-2xl overflow-hidden border border-border hover:border-primary/40 transition-all duration-500 hover:-translate-y-3 ${
                index === 1 ? 'lg:translate-y-8' : ''
              }`}
            >
              {/* Gradient Header */}
              <div className={`h-2 bg-gradient-to-r ${project.color}`} />
              
              {/* Icon & Type Badge */}
              <div className="p-8">
                <div className="flex items-start justify-between mb-6">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${project.color} bg-opacity-20 flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <project.icon className="w-8 h-8 text-foreground" />
                  </div>
                  <span className="px-3 py-1 text-xs font-bold uppercase tracking-wider bg-muted text-muted-foreground rounded-full">
                    {project.type}
                  </span>
                </div>

                {/* Content */}
                <h3 className="font-display text-xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-6 leading-relaxed line-clamp-3">
                  {project.description}
                </p>

                {/* Outcomes */}
                {project.outcomes.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.outcomes.slice(0, 3).map((outcome) => (
                      <span
                        key={outcome}
                        className="px-3 py-1 text-xs bg-primary/10 text-primary rounded-full border border-primary/20"
                      >
                        {outcome}
                      </span>
                    ))}
                  </div>
                )}

                {/* CTA */}
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-primary hover:text-secondary transition-colors group/link"
                >
                  <span className="font-medium">View Project</span>
                  <ExternalLink size={16} className="group-hover/link:translate-x-1 group-hover/link:-translate-y-1 transition-transform" />
                </a>
              </div>

              {/* Hover Glow Effect */}
              <div className={`absolute inset-0 bg-gradient-to-br ${project.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500 pointer-events-none`} />
            </article>
          ))}
        </div>

        {/* Coming Soon Card */}
        <div className="max-w-md mx-auto">
          {projects.filter(p => !p.featured).map((project) => (
            <div
              key={project.title}
              className="glass-card p-6 rounded-xl text-center"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${project.color} bg-opacity-20 flex items-center justify-center mx-auto mb-4`}>
                <project.icon className="w-6 h-6 text-muted-foreground" />
              </div>
              <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                {project.title}
              </h3>
              <p className="text-muted-foreground text-sm">
                {project.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Diagonal Divider */}
      <svg 
        className="absolute bottom-0 left-0 right-0 w-full h-16 text-card"
        viewBox="0 0 1440 48" 
        preserveAspectRatio="none"
      >
        <path 
          d="M0,48 L1440,48 L1440,24 L0,0 Z" 
          fill="currentColor"
        />
      </svg>
    </section>
  );
};

export default ProjectsSection;
